"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";

interface Candidate {
  id: string;
  number: number;
  name: string;
  bio: string | null;
  imageUrl: string | null;
  voteCount: number;
}

const PRIX_PAR_VOTE = 200;

export default function VotePage() {
  const params = useParams();
  const router = useRouter();
  const candidateId = params.candidateId as string;

  const [candidate, setCandidate] = useState<Candidate | null>(null);
  const [numberOfVotes, setNumberOfVotes] = useState(1);
  const [voterPhone, setVoterPhone] = useState("");
  const [voterName, setVoterName] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetch("/api/candidates")
      .then((res) => res.json())
      .then((data: Candidate[]) => {
        const found = data.find((c) => c.id === candidateId);
        setCandidate(found || null);
      });
  }, [candidateId]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    if (!voterPhone.trim()) {
      setError("Merci d'indiquer ton numéro de téléphone (utilisé pour le paiement mobile money).");
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/payment/init", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ candidateId, numberOfVotes, voterPhone, voterName }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Une erreur est survenue.");
        setSubmitting(false);
        return;
      }

      // Redirection vers la page de paiement CinetPay
      window.location.href = data.paymentUrl;
    } catch {
      setError("Impossible de contacter le serveur. Réessaie dans un instant.");
      setSubmitting(false);
    }
  }

  if (!candidate) {
    return <p className="text-center mt-20 text-gray-500">Chargement...</p>;
  }

  const total = numberOfVotes * PRIX_PAR_VOTE;

  return (
    <main className="max-w-md mx-auto px-4 py-10">
      <Link href="/" className="text-rose-500 text-sm">
        ← Retour aux candidates
      </Link>

      <div className="bg-white rounded-xl shadow mt-4 overflow-hidden border border-rose-100">
        <div className="aspect-[3/4] bg-rose-100 flex items-center justify-center overflow-hidden">
          {candidate.imageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={candidate.imageUrl} alt={candidate.name} className="w-full h-full object-cover" />
          ) : (
            <span className="text-rose-300 text-6xl">👑</span>
          )}
        </div>
        <div className="p-5">
          <p className="text-xs text-rose-500 font-semibold">Candidate n°{candidate.number}</p>
          <h1 className="text-2xl font-bold">{candidate.name}</h1>
          {candidate.bio && <p className="text-gray-600 mt-2 text-sm">{candidate.bio}</p>}
          <p className="text-sm text-gray-500 mt-2">{candidate.voteCount} vote(s) actuellement</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow mt-6 p-5 border border-rose-100">
        <h2 className="font-bold text-lg mb-4">Voter pour {candidate.name}</h2>

        <label className="block text-sm font-medium mb-1">Nombre de votes</label>
        <input
          type="number"
          min={1}
          max={1000}
          value={numberOfVotes}
          onChange={(e) => setNumberOfVotes(parseInt(e.target.value) || 1)}
          className="w-full border border-gray-300 rounded-lg px-3 py-2 mb-4"
        />

        <label className="block text-sm font-medium mb-1">Ton numéro de téléphone (mobile money)</label>
        <input
          type="tel"
          placeholder="Ex: 97000000"
          value={voterPhone}
          onChange={(e) => setVoterPhone(e.target.value)}
          className="w-full border border-gray-300 rounded-lg px-3 py-2 mb-4"
          required
        />

        <label className="block text-sm font-medium mb-1">Ton nom (optionnel)</label>
        <input
          type="text"
          placeholder="Ex: Marie K."
          value={voterName}
          onChange={(e) => setVoterName(e.target.value)}
          className="w-full border border-gray-300 rounded-lg px-3 py-2 mb-4"
        />

        <div className="flex justify-between items-center mb-4 text-lg font-bold">
          <span>Total à payer</span>
          <span className="text-rose-600">{total} FCFA</span>
        </div>

        {error && <p className="text-red-600 text-sm mb-4">{error}</p>}

        <button
          type="submit"
          disabled={submitting}
          className="w-full bg-rose-600 text-white font-semibold py-3 rounded-lg hover:bg-rose-700 disabled:opacity-50"
        >
          {submitting ? "Redirection vers le paiement..." : `Payer ${total} FCFA et voter`}
        </button>
      </form>
    </main>
  );
}
