"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";

export default function MerciPage() {
  const searchParams = useSearchParams();
  const paymentId = searchParams.get("paymentId");
  const [status, setStatus] = useState<"loading" | "success" | "pending" | "failed">("loading");
  const [info, setInfo] = useState<any>(null);

  useEffect(() => {
    if (!paymentId) {
      setStatus("failed");
      return;
    }

    // On vérifie le statut toutes les 3 secondes pendant 30 secondes max,
    // car le webhook CinetPay peut prendre quelques secondes à arriver.
    let attempts = 0;
    const interval = setInterval(async () => {
      attempts++;
      const res = await fetch(`/api/payment/status?paymentId=${paymentId}`);
      const data = await res.json();
      setInfo(data);

      if (data.status === "success") {
        setStatus("success");
        clearInterval(interval);
      } else if (data.status === "failed" || attempts >= 10) {
        setStatus(data.status === "failed" ? "failed" : "pending");
        clearInterval(interval);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [paymentId]);

  return (
    <main className="max-w-md mx-auto px-4 py-20 text-center">
      {status === "loading" && <p>Vérification du paiement en cours...</p>}

      {status === "success" && (
        <div>
          <p className="text-5xl mb-4">🎉</p>
          <h1 className="text-2xl font-bold text-green-600 mb-2">Merci pour ton vote !</h1>
          <p className="text-gray-600">
            {info?.numberOfVotes} vote(s) ont été enregistrés pour {info?.candidateName}.
          </p>
        </div>
      )}

      {status === "pending" && (
        <div>
          <p className="text-5xl mb-4">⏳</p>
          <h1 className="text-2xl font-bold text-amber-600 mb-2">Paiement en attente</h1>
          <p className="text-gray-600">
            Si tu as confirmé le paiement sur ton téléphone, ton vote sera bientôt comptabilisé.
            Rafraîchis cette page dans une minute.
          </p>
        </div>
      )}

      {status === "failed" && (
        <div>
          <p className="text-5xl mb-4">❌</p>
          <h1 className="text-2xl font-bold text-red-600 mb-2">Paiement échoué</h1>
          <p className="text-gray-600">Le paiement n&apos;a pas pu être confirmé. Tu peux réessayer.</p>
        </div>
      )}

      <Link href="/" className="inline-block mt-8 text-rose-600 font-semibold">
        ← Retour à la liste des candidates
      </Link>
    </main>
  );
}
