"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

interface Result {
  id: string;
  number: number;
  name: string;
  voteCount: number;
}

interface Stats {
  results: Result[];
  totalVotes: number;
  totalAmount: number;
  pendingPayments: number;
  failedPayments: number;
}

export default function AdminDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  async function loadStats() {
    const res = await fetch("/api/admin/stats");
    if (res.status === 401) {
      router.push("/admin");
      return;
    }
    const data = await res.json();
    setStats(data);
    setLoading(false);
  }

  useEffect(() => {
    loadStats();
    // Rafraîchissement automatique toutes les 10 secondes pour suivre le vote en direct
    const interval = setInterval(loadStats, 10000);
    return () => clearInterval(interval);
  }, []);

  if (loading || !stats) {
    return <p className="text-center mt-20 text-gray-500">Chargement des statistiques...</p>;
  }

  return (
    <main className="max-w-3xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold mb-6">Tableau de bord — Résultats en direct</h1>

      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="bg-white rounded-xl shadow p-4 text-center border border-gray-100">
          <p className="text-2xl font-bold text-rose-600">{stats.totalVotes}</p>
          <p className="text-sm text-gray-500">Votes confirmés</p>
        </div>
        <div className="bg-white rounded-xl shadow p-4 text-center border border-gray-100">
          <p className="text-2xl font-bold text-green-600">{stats.totalAmount.toLocaleString()} F</p>
          <p className="text-sm text-gray-500">Total encaissé</p>
        </div>
        <div className="bg-white rounded-xl shadow p-4 text-center border border-gray-100">
          <p className="text-2xl font-bold text-amber-500">{stats.pendingPayments}</p>
          <p className="text-sm text-gray-500">Paiements en attente</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow border border-gray-100 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 text-sm text-gray-500">
            <tr>
              <th className="px-4 py-3">Rang</th>
              <th className="px-4 py-3">N°</th>
              <th className="px-4 py-3">Candidate</th>
              <th className="px-4 py-3 text-right">Votes</th>
            </tr>
          </thead>
          <tbody>
            {stats.results.map((r, i) => (
              <tr key={r.id} className="border-t border-gray-100">
                <td className="px-4 py-3 font-bold">{i + 1}</td>
                <td className="px-4 py-3 text-gray-500">{r.number}</td>
                <td className="px-4 py-3">{r.name}</td>
                <td className="px-4 py-3 text-right font-semibold text-rose-600">{r.voteCount}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="text-xs text-gray-400 mt-4 text-center">
        Mise à jour automatique toutes les 10 secondes.
      </p>
    </main>
  );
}
