import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Miss Vote — Votez pour votre candidate préférée",
  description: "Site officiel de vote pour le concours Miss",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body className="bg-rose-50 min-h-screen text-gray-800">{children}</body>
    </html>
  );
}
