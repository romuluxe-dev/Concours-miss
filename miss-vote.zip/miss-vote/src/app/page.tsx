"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface Candidate {
  id: string;
  number: number;
  name: string;
  bio: string | null;
  imageUrl: string | null;
  voteCount: number;
}

export default function HomePage() {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/candidates")
      .then((res) => res.json())
      .then((data) => {
        setCandidates(data);
        setLoading(false);
      });
  }, []);

  return (
    <main className="max-w-6xl mx-auto px-4 py-10">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold text-rose-600 mb-2">Concours Miss</h1>
        <p className="text-gray-600">
          Votez pour votre candidate préférée — chaque vote coûte <strong>200 FCFA</strong>
        </p>
      </header>

      {loading ? (
        <p className="text-center text-gray-500">Chargement des candidates...</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {candidates.map((c) => (
            <Link
              key={c.id}
              href={`/vote/${c.id}`}
              className="bg-white rounded-xl shadow hover:shadow-lg transition overflow-hidden border border-rose-100"
            >
              <div className="aspect-[3/4] bg-rose-100 flex items-center justify-center overflow-hidden">
                {c.imageUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={c.imageUrl} alt={c.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-rose-300 text-5xl">👑</span>
                )}
              </div>
              <div className="p-4">
                <p className="text-xs text-rose-500 font-semibold">Candidate n°{c.number}</p>
                <h2 className="text-lg font-bold">{c.name}</h2>
                <p className="text-sm text-gray-500 mt-1">{c.voteCount} vote(s)</p>
              </div>
            </Link>
          ))}
        </div>
      )}
    </main>
  );
}
