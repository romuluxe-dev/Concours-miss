// Ce script remplit la base de données avec :
// - 15 candidates "placeholder" (à modifier ensuite depuis l'admin)
// - 1 compte administrateur par défaut
//
// Pour l'exécuter : npm run db:seed

const { PrismaClient } = require("@prisma/client");
const bcrypt = require("bcryptjs");

const prisma = new PrismaClient();

async function main() {
  // 15 candidates placeholder
  for (let i = 1; i <= 15; i++) {
    await prisma.candidate.upsert({
      where: { number: i },
      update: {},
      create: {
        number: i,
        name: `Candidate ${i}`,
        bio: "Biographie à compléter depuis l'espace admin.",
        imageUrl: "/images/placeholder.svg",
      },
    });
  }

  // Compte admin par défaut — CHANGE CE MOT DE PASSE DÈS LA PREMIÈRE CONNEXION
  const passwordHash = await bcrypt.hash("ChangeMoi123!", 10);
  await prisma.admin.upsert({
    where: { email: "admin@missvote.com" },
    update: {},
    create: {
      email: "admin@missvote.com",
      passwordHash,
    },
  });

  console.log("✅ Base de données initialisée : 15 candidates + 1 compte admin");
  console.log("   Email admin : admin@missvote.com");
  console.log("   Mot de passe : ChangeMoi123!  (à changer immédiatement)");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
